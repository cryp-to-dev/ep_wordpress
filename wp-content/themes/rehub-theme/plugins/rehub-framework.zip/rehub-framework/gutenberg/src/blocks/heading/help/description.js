const {__} = wp.i18n;
const description = __('Heading with number in background', 'rehub-framework');
export default description;
