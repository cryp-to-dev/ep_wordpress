export default 'editor-spellcheck';

