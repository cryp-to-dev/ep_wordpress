const {__} = wp.i18n;
const description = __('Bordered Box with title', 'rehub-framework');
export default description;

