const {__} = wp.i18n;
const title = __('Title box', 'rehub-framework');
export default title;
