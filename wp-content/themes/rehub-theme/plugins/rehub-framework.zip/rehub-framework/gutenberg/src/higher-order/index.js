// HOCs for edit components.
export {default as withUniqueClass} from './with-unique-class';
export {default as withBlockStyles} from './with-block-styles';